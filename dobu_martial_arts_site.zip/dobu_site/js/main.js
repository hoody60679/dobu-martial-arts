// ===== PAGE NAVIGATION =====
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));

  const target = document.getElementById(id);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('onclick') && a.getAttribute('onclick').includes("'" + id + "'")) {
      a.classList.add('active');
    }
  });

  closeNav();
}

// ===== HAMBURGER MENU =====
function toggleNav() {
  const navLinks = document.getElementById('navLinks');
  const hamburger = document.getElementById('hamburger');
  const isOpen = navLinks.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', isOpen.toString());
}

function closeNav() {
  const navLinks = document.getElementById('navLinks');
  const hamburger = document.getElementById('hamburger');
  navLinks.classList.remove('open');
  if (hamburger) hamburger.setAttribute('aria-expanded', 'false');
}

// Close nav when clicking outside
document.addEventListener('click', function (e) {
  const nav = document.querySelector('nav');
  const navLinks = document.getElementById('navLinks');
  if (nav && navLinks && !nav.contains(e.target) && navLinks.classList.contains('open')) {
    closeNav();
  }
});

// ===== CONTACT FORM VALIDATION =====
document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    let valid = true;

    function validate(fieldId, errorId, condition) {
      const error = document.getElementById(errorId);
      if (!error) return;
      if (condition) {
        error.style.display = 'block';
        valid = false;
      } else {
        error.style.display = 'none';
      }
    }

    const firstName = document.getElementById('firstName').value.trim();
    const lastName  = document.getElementById('lastName').value.trim();
    const email     = document.getElementById('email').value.trim();
    const enquiry   = document.getElementById('enquiry').value;
    const message   = document.getElementById('message').value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    validate('firstName', 'firstNameError', firstName === '');
    validate('lastName',  'lastNameError',  lastName === '');
    validate('email',     'emailError',     !emailRegex.test(email));
    validate('enquiry',   'enquiryError',   enquiry === '');
    validate('message',   'messageError',   message === '');

    if (valid) {
      const success = document.getElementById('formSuccess');
      if (success) {
        success.style.display = 'block';
        form.reset();
        setTimeout(() => { success.style.display = 'none'; }, 6000);
      }
    }
  });

  // Clear errors on input
  ['firstName', 'lastName', 'email', 'enquiry', 'message'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', function () {
        const err = document.getElementById(id + 'Error');
        if (err) err.style.display = 'none';
      });
    }
  });
});
